// MyObject.cpp
#include "MyObject.h"

MyObject::MyObject(QObject *parent) : QObject(parent), m_message("Hello from C++!") {}

//void MyObject::updateTest()
//{
//    test++;
//}
QString MyObject::message() const
{
    return m_message;
}

void MyObject::setMessage(const QString &newMessage)
{
    if (m_message != newMessage) {
        m_message = newMessage;
        emit messageChanged();
    }
}
