// MyObject.h
#ifndef MYOBJECT_H
#define MYOBJECT_H

#include <QObject>

class MyObject : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString message READ message WRITE setMessage NOTIFY messageChanged)

public:
    explicit MyObject(QObject *parent = nullptr);

    QString message() const;

//    int test;
//    void updateTest();
public slots:
    void setMessage(const QString &newMessage);

signals:
    void messageChanged();

private:
    QString m_message;
};

#endif // MYOBJECT_H
